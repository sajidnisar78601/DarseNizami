# CleanArchitectureTemplate

This is a fully functional sample project following the "Clean Architecture" principles. Please read more [here](https://github.com/jacobduijzer/CleanArchitectureTemplate).


